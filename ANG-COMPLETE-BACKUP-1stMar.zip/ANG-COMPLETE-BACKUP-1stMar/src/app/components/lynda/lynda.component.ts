import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lynda',
  templateUrl: './lynda.component.html',
  styleUrls: ['./lynda.component.css']
})
export class LyndaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
