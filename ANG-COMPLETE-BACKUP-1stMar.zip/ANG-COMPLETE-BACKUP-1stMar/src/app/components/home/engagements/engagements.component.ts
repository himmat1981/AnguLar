import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-engagements',
  templateUrl: './engagements.component.html',
  styleUrls: ['./engagements.component.css']
})
export class EngagementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
