import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCareerPathComponent } from './my-career-path.component';

describe('MyCareerPathComponent', () => {
  let component: MyCareerPathComponent;
  let fixture: ComponentFixture<MyCareerPathComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyCareerPathComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyCareerPathComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
