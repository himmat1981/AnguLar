import { Component, OnInit } from '@angular/core';

import { CoursesService } from '../../../../services/courses.service';

@Component({
  selector: 'app-my-team',
  templateUrl: './my-team.component.html',
  styleUrls: ['./my-team.component.css']
})
export class MyTeamComponent implements OnInit {
  public myTeam: any;
  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.get_my_team();
  }

  get_my_team() {
    this.courses_service.getMyTeam()
      .subscribe( resp => (this.myTeam = resp['data']['TeamMembers'])
      );
  }

}
