import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadyForRoleComponent } from './ready-for-role.component';

describe('ReadyForRoleComponent', () => {
  let component: ReadyForRoleComponent;
  let fixture: ComponentFixture<ReadyForRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadyForRoleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadyForRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
