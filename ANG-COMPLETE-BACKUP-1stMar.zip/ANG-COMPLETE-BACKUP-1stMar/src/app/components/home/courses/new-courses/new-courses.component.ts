import { Component, OnInit } from '@angular/core';

import { CoursesService } from '../../../../services/courses.service';
@Component({
  selector: 'app-new-courses',
  templateUrl: './new-courses.component.html',
  styleUrls: ['./new-courses.component.css']
})
export class NewCoursesComponent implements OnInit {

  public newCourses:  any;

  constructor(private courses_service: CoursesService) { }

  ngOnInit() {
    this.get_new_courses();
  }

  get_new_courses() {
    this.courses_service.getNewCourses()
      .subscribe( resp => (this.newCourses = resp['data'])
      );
  }

}
