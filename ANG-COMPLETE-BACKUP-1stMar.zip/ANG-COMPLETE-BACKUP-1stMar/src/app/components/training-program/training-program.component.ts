import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-program',
  templateUrl: './training-program.component.html',
  styleUrls: ['./training-program.component.css']
})
export class TrainingProgramComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
