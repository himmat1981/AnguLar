import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { NewCoursesComponent } from './components/home/courses/new-courses/new-courses.component';
import { PopularCoursesComponent } from './components/home/courses/popular-courses/popular-courses.component';

import { EngagementsComponent } from './components/home/engagements/engagements.component';
import { CoursesComponent } from './components/home/courses/courses.component';
import { MyAccountComponent } from './components/home/my-account/my-account.component';

import { MyTrainingComponent } from './components/home/my-account/my-training/my-training.component';
import { MyCareerPathComponent } from './components/home/my-account/my-career-path/my-career-path.component';
import { MyTeamComponent } from './components/home/my-account/my-team/my-team.component';

import { ReadyForRoleComponent } from './components/home/my-account/my-training/ready-for-role/ready-for-role.component';
import { MandatoryComponent } from './components/home/my-account/my-training/mandatory/mandatory.component';
import { RecommendedComponent } from './components/home/my-account/my-training/recommended/recommended.component';

const routes: Routes = [
  // { path:  '', redirectTo:  'home', pathMatch:  'full' },
  // {
  //   path: 'home',
  //   component: HomeComponent,
  //   children: [
  //     { path: '', redirectTo: 'my-account', pathMatch: 'full' },
  //     {
  //       path: 'my-account',
  //       component: MyAccountComponent,
  //       children: [
  //                   { path: '', redirectTo: 'my-training', pathMatch: 'full' },
  //                   { path: 'my-training', component: MyTrainingComponent,
  //                     children : [
  //                                 { path: '', redirectTo: 'ready-for-role', pathMatch: 'full' },
  //                                 { path: 'ready-for-role', component: ReadyForRoleComponent },
  //                                 { path: 'mandatory', component: MandatoryComponent },
  //                                 { path: 'recommended', component: RecommendedComponent }
  //                                ]
  //                   },
  //                   { path: 'my-career-path', component: MyCareerPathComponent },
  //                   { path: 'my-team', component: MyTeamComponent }
  //                 ]
  //     },
  //     {
  //       path: 'courses',
  //       component: CoursesComponent,
  //       children: [ 
  //                   { path: '', redirectTo: 'popular-courses', pathMatch: 'full' },
  //                   { path: 'popular-courses', component: PopularCoursesComponent },
  //                   { path: 'new-courses', component: NewCoursesComponent }
  //                 ]
  //     },
  //     { path: 'engagements', component: EngagementsComponent }
  //   ]
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
